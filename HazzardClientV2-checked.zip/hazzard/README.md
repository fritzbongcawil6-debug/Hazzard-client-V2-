# Hazzard Client V2 — Minecraft Java 1.21.11

A Fabric client-side mod starter with a custom HUD, FPS readout, coordinates, enabled-module list, and a click-to-toggle module menu.

## Build locally
- Install JDK 21.
- Install Gradle 8.14+ (or open the project in an IDE that can install/use Gradle).
- From this folder run `gradle build`.
- The mod JAR should be written to `build/libs/`.

## Use
Install the JAR in the `mods` folder of a Minecraft 1.21.11 instance with compatible Fabric Loader and Fabric API. Press **Right Shift** to open/close the menu.

## Current implementation status
- Implemented: client HUD header, optional FPS text, coordinates display toggle, array-list display, menu opening, module list rendering, click-to-toggle, and arrow-key scrolling.
- The registry has 100+ module entries, but most are placeholders; they do not implement the gameplay behavior implied by their names.
- No configuration persistence or searchable input has been implemented yet.
- This source has not been compiled or tested in-game in this environment.
