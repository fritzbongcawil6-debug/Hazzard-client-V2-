package com.hazzard.client;

import java.util.*;

public final class ModuleRegistry {
    private static final List<ClientModule> MODULES = new ArrayList<>();
    private static final Map<String, ClientModule> BY_NAME = new LinkedHashMap<>();
    private ModuleRegistry() {}

    public static void registerDefaults() {
        if (!MODULES.isEmpty()) return;
        add("HUD", "Visual", true); add("Array List", "Visual", true);
        add("Coordinates", "Visual", true); add("FPS Counter", "Visual", true);
        add("Clock", "Visual", false); add("Keystrokes", "Visual", false);
        add("Armor Status", "Visual", false); add("Durability", "Visual", false);
        add("Crosshair", "Visual", false); add("Toggle Sprint", "Movement", false);
        String[] names = {
          "Fullbright","Gamma Control","Time Display","Weather Display","Biome Display","Direction HUD","Compass HUD","Ping Display","Memory Display","CPS Counter",
          "Reach Display","Hitbox Display","Entity Counter","Item Counter","Potion Status","Effect Timer","Totem Counter","Target HUD","Inventory HUD","Scoreboard HUD",
          "Chat Timestamps","Chat Cleaner","Compact Chat","Screenshot Notifier","Zoom","Freecam","Perspective","Smooth Camera","Camera Clip","View Bobbing",
          "Auto Walk","Safe Walk","Sprint Assist","Sneak Assist","Step Assist","Elytra HUD","Horse Stats","Boat HUD","Mount HUD","Velocity Display",
          "Block Outline","Block Info","Tool Info","Durability Warning","Container Preview","Sign Preview","Shulker Preview","Item Preview","Recipe Helper","Crafting Helper",
          "Waypoint List","Waypoint Distance","Death Coordinates","Last Location","World Info","Seed Display","Chunk Borders","Light Level","Slime Chunk Notes","Spawn Point HUD",
          "Sound Subtitles","Sound Meter","Particle Toggle","Weather Particles","Fire Overlay","Hurt Camera","Totem Animation","No Pumpkin Overlay","Low Fire","Clear Water",
          "Screenshot Mode","Stream Mode","Minimal HUD","Boss Bar Toggle","Scoreboard Toggle","Tab List Toggle","Title Toggle","Vignette Toggle","Fog Toggle","Panorama Menu",
          "Module Search","Click GUI","Theme Editor","Accent Color","HUD Editor","Panel Snap","UI Scale","Compact Panels","Notifications","Config Manager",
          "Profile One","Profile Two","Profile Three","Export Settings","Import Settings","Reset Settings","Debug Info","Performance Monitor","Resource Pack Info","Mod List"
        };
        String[] categories = {"Visual","Movement","World","Utility","Interface"};
        for (int i = 0; i < names.length; i++) add(names[i], categories[i % categories.length], false);
    }
    private static void add(String name, String category, boolean enabled) {
        ClientModule module = new ClientModule(name, category, enabled);
        MODULES.add(module); BY_NAME.put(name.toLowerCase(Locale.ROOT), module);
    }
    public static List<ClientModule> all() { return Collections.unmodifiableList(MODULES); }
    public static Optional<ClientModule> find(String name) { return Optional.ofNullable(BY_NAME.get(name.toLowerCase(Locale.ROOT))); }
    public static long enabledCount() { return MODULES.stream().filter(ClientModule::enabled).count(); }
}
