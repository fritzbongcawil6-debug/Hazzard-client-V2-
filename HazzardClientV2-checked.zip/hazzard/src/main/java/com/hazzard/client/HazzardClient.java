package com.hazzard.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class HazzardClient implements ClientModInitializer {
    private static KeyBinding menuKey;
    private static boolean menuOpen;
    private static int scroll;
    private static String filter = "";
    private static boolean leftMouseWasDown;
    private static boolean upWasDown;
    private static boolean downWasDown;

    @Override public void onInitializeClient() {
        ModuleRegistry.registerDefaults();
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.hazzardclient.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
            KeyBinding.Category.MISC
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) menuOpen = !menuOpen;
        });
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> renderHud(drawContext));
    }

    private static void renderHud(net.minecraft.client.gui.DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        int width = mc.getWindow().getScaledWidth();
        int height = mc.getWindow().getScaledHeight();
        int y = 8;
        boolean hudEnabled = ModuleRegistry.find("HUD").orElseThrow().enabled();
        if (hudEnabled) {
            ctx.fill(7, 7, 132, 28, 0xB9151720);
            ctx.fill(7, 7, 10, 28, 0xFFFF4D5A);
            ctx.drawText(mc.textRenderer, Text.literal("HAZZARD V2"), 16, 10, 0xFFFF5967, false);
            if (ModuleRegistry.find("FPS Counter").orElseThrow().enabled()) {
                ctx.drawText(mc.textRenderer, Text.literal("1.21.11  •  " + mc.getCurrentFps() + " FPS"), 16, 19, 0xFFE3E7F0, false);
            }
        }
        if (hudEnabled && ModuleRegistry.find("Coordinates").orElseThrow().enabled()) {
            String coords = String.format("XYZ  %d  /  %d  /  %d", (int)mc.player.getX(), (int)mc.player.getY(), (int)mc.player.getZ());
            ctx.drawText(mc.textRenderer, Text.literal(coords), 8, height - 18, 0xFFFFFFFF, true);
        }
        if (hudEnabled && ModuleRegistry.find("Array List").orElseThrow().enabled()) {
            for (ClientModule module : ModuleRegistry.all()) {
                if (!module.enabled() || module.name().equals("HUD") || module.name().equals("Array List")) continue;
                String text = module.name();
                int x = width - mc.textRenderer.getWidth(text) - 9;
                ctx.fill(x - 4, y - 2, width - 5, y + 10, 0xA9151720);
                ctx.fill(width - 7, y - 2, width - 5, y + 10, 0xFFFF5967);
                ctx.drawText(mc.textRenderer, Text.literal(text), x, y, 0xFFFFFFFF, false);
                y += 12;
            }
        }
        if (menuOpen) renderMenu(ctx, mc, width, height);
    }

    private static void renderMenu(net.minecraft.client.gui.DrawContext ctx, MinecraftClient mc, int width, int height) {
        int panelW = 270, panelH = Math.min(height - 32, 330);
        int x = (width - panelW) / 2, y = (height - panelH) / 2;
        ctx.fill(0, 0, width, height, 0x70000000);
        ctx.fill(x, y, x + panelW, y + panelH, 0xF0161822);
        ctx.fill(x, y, x + panelW, y + 25, 0xFF262A38);
        ctx.fill(x, y, x + 3, y + panelH, 0xFFFF5967);
        ctx.drawText(mc.textRenderer, Text.literal("HAZZARD CLIENT V2"), x + 12, y + 8, 0xFFFF6874, false);
        ctx.drawText(mc.textRenderer, Text.literal("RIGHT SHIFT: CLOSE  •  CLICK: TOGGLE"), x + 12, y + 31, 0xFFADB5C8, false);
        double mouseX = mc.mouse.getX() * width / mc.getWindow().getWidth();
        double mouseY = mc.mouse.getY() * height / mc.getWindow().getHeight();
        boolean leftDown = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean justClicked = leftDown && !leftMouseWasDown;
        leftMouseWasDown = leftDown;

        int rowY = y + 48;
        int shown = 0;
        for (ClientModule module : ModuleRegistry.all()) {
            if (!filter.isEmpty() && !module.name().toLowerCase(java.util.Locale.ROOT).contains(filter)) continue;
            if (shown++ < scroll) continue;
            if (rowY > y + panelH - 18) break;
            boolean on = module.enabled();
            boolean hovered = mouseX >= x + 9 && mouseX <= x + panelW - 9 && mouseY >= rowY - 2 && mouseY <= rowY + 13;
            ctx.fill(x + 9, rowY - 2, x + panelW - 9, rowY + 13,
                hovered ? 0xFF414657 : (on ? 0xFF343747 : 0xFF20232D));
            ctx.drawText(mc.textRenderer, Text.literal(module.name()), x + 15, rowY + 1, on ? 0xFFFFFFFF : 0xFFADB2C1, false);
            ctx.drawText(mc.textRenderer, Text.literal(on ? "ON" : "OFF"), x + panelW - 35, rowY + 1, on ? 0xFFFF6874 : 0xFF7D8495, false);
            if (justClicked && hovered) module.toggle();
            rowY += 17;
        }
        // Arrow keys page through the module list while the menu is open.
        boolean downNow = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_DOWN) == GLFW.GLFW_PRESS;
        boolean upNow = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_UP) == GLFW.GLFW_PRESS;
        if (downNow && !downWasDown) scroll = Math.min(scroll + 1, Math.max(0, ModuleRegistry.all().size() - 1));
        if (upNow && !upWasDown) scroll = Math.max(0, scroll - 1);
        downWasDown = downNow;
        upWasDown = upNow;
        ctx.drawText(mc.textRenderer, Text.literal("Modules: " + ModuleRegistry.all().size() + "  |  Enabled: " + ModuleRegistry.enabledCount()), x + 12, y + panelH - 12, 0xFFADB5C8, false);
    }

    public static boolean isMenuOpen() { return menuOpen; }
    public static void closeMenu() { menuOpen = false; }
}
